#Python 3
a,b = input().split()
print(int(a)+int(b))
